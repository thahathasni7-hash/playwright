import {test,expect} from '@playwright/test'
import { LoginPage } from '../pages/loginpage'
import  validlogindata from '../utils/parameterisedtestdata.json'
for(const data of validlogindata){


test(`login using valid credentials ${data.username} ${data.password}`,async({page})=>{
const lp=new LoginPage(page)
await lp.openApplication(data.username,data.password)
await expect(page).toHaveURL('https://www.saucedemo.com/inventory.html')

})
}