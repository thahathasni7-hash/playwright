import {test,expect} from '@playwright/test'
import {LoginPage} from '../pages/loginpage'
test('verify login with valid credentials',async({page})=>{
const lp=new LoginPage(page)
await lp.openApplication()
await lp.login()
//await expect(page).toHaveURL('https://www.saucedemo.com/inventory.html')
})